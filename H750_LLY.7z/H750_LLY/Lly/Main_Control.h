//
// Created by 29787 on 2024/10/25.
//

#ifndef PROJECT_MAIN_CONTROL_H
#define PROJECT_MAIN_CONTROL_H

_Noreturn void Main_();


#endif //PROJECT_MAIN_CONTROL_H
