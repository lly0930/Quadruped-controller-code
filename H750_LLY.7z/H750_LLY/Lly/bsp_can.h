#include "main.h"
#include "fdcan.h"

void FDCAN1_RX_Filter_Init(void);
uint8_t FDCAN1_Send_Msg(uint16_t id,uint8_t* msg,uint32_t len);

